['/cor_society/main']
