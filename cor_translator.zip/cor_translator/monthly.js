['/cor_translator/main']
